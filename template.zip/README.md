To submit your skill, replace this file with text from 
https://rawgit.com/MycroftAI/mycroft-skills/master/meta_editor.html


## YOUR SKILL NAME
One line description of the skill

eg. "Verbally control Pomodoro timing and activities"
eg. "Verbally search and play Spotify tracks and playlists"

It's better not to use "This Skill does xxxx" as it's not as readable. 

## Description 
A more verbose description, including any extra instructions or
information that didn't fit in the one line.

## Examples 
* "Hello world"
* "Greetings planet earth"
* "Count up"
* "Count down"

## Credits 
Your name
